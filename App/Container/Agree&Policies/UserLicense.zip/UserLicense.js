import React, { Component } from 'react';
import {
  StyleSheet,
  Text, Linking,
  View,
  TouchableHighlight, TouchableOpacity,
  Image, TextInput,
  Alert,
  ScrollView,
  SafeAreaView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import ValidationComponent from 'react-native-form-validator';
import { Colors, Fonts, Images, Metrics, Helpers, ApplicationStyles } from 'App/Theme'
import CustomHeaderNew from 'App/Components/CustomHeaderNew';
import ButtonWithTextandImage from 'App/Components/ButtonWithTextandImage';
import { connect } from 'react-redux'
import { PropTypes } from 'prop-types'
import AuthenticateActions from 'App/Stores/Authentication/Actions'
import NavigationService from 'App/Services/NavigationService'
import { Enums } from 'App/Enums';
import CustomPopUpDailog from 'App/Components/CustomPopUpDailog';

class UserLicense extends ValidationComponent {

  constructor(props) {
    super(props);
    this.state = {  IsMessageShow: false, Message: '' };

  }

  componentWillUnmount() {
   
  }

  _OnClickCrossButton() {
    NavigationService.navigate('AccountTypeScreen')
  }






  render() {


    const IsFacility = this.props.accountType == Enums.Facility

    return (

      <SafeAreaView style={[Helpers.fill, { backgroundColor: Colors.white }]}>

<CustomHeaderNew
          HeaderColor={{ backgroundColor:Colors.white}}
          onPressBackButton={this._OnClickCrossButton.bind(this)}
        //  HeaderTitle={this.props.selectedMessage["EULA-EndUserLicenceAgreement"]}
          HeaderTitle="Patients Details"
       
          LeftImage={Images.PurPleBackIcon}
          textcolorHeader='#614698'
        />
        <ScrollView >
<View style={{height:50}}>

</View>

<View style={{backgroundColor:'white',alignSelf:'center',width:'90%',borderRadius:15,
shadowOffset:{ width: 5, height: 5, },
shadowOpacity: 0.2,
shadowColor:'#614698',
elevation: 15,}}>

<View style={{flexDirection:'row',justifyContent:'space-between'}}>
<Text style={[Helpers.mediumFont, { fontSize: 17,marginLeft: 20, textAlign: 'left', marginTop: 10, color: '#152C52',width:'30%'  }]}>
       Name:
</Text>
<Text numberOfLines={2} style={[Helpers.lightBook, { fontSize: 17, textAlign: 'left', marginTop: 10, color: '#152C52',width:'60%'  }]}>
Priya Sharma 
</Text>
</View>
<View style={{height:1.5,marginTop:13,backgroundColor:'#EEEEEE',width:'90%',alignSelf:'center'}}>

</View>
<View style={{flexDirection:'row',justifyContent:'space-between'}}>
<Text style={[Helpers.mediumFont, { fontSize: 17,marginLeft: 20, textAlign: 'left', marginTop: 10, color: '#152C52',width:'30%'  }]}>
Address:
</Text>
<Text style={[Helpers.lightBook, { fontSize: 17, textAlign: 'left', marginTop: 10, color: '#152C52',width:'60%',  }]}>
       House No. 1005, uraban estate
phase 1, guru teg bahadur
nagar, Ludhiana Punjab
</Text>
</View>
<View style={{height:1.5,marginTop:13,backgroundColor:'#EEEEEE',width:'90%',alignSelf:'center'}}>

</View>
<View style={{flexDirection:'row',justifyContent:'space-between'}}>
<Text style={[Helpers.mediumFont, { fontSize: 17,marginLeft: 20, textAlign: 'left', marginTop: 10, color: '#152C52',width:'30%'  }]}>
Pincode:
</Text>
<Text style={[Helpers.lightBook, { fontSize: 17, textAlign: 'left', marginTop: 10, color: '#152C52',width:'60%',  }]}>
141001
</Text>
</View>

<View style={{height:1.5,marginTop:13,backgroundColor:'#EEEEEE',width:'90%',alignSelf:'center'}}>

</View>
<View style={{flexDirection:'row',justifyContent:'space-between'}}>
<Text style={[Helpers.mediumFont, { fontSize: 17,marginLeft: 20, textAlign: 'left', marginTop: 10, color: '#152C52',width:'30%'  }]}>
DOB:
</Text>
<Text style={[Helpers.lightBook, { fontSize: 17, textAlign: 'left', marginTop: 10, color: '#152C52',width:'60%',  }]}>
12/04/1988
</Text>
</View>
<View style={{height:1.5,marginTop:13,backgroundColor:'#EEEEEE',width:'90%',alignSelf:'center'}}>

</View>
<View style={{height:100}}>

</View>



</View>

<View style={{height:50}}>

</View>



        </ScrollView>

        <View style={[Helpers.btnContainer, { marginBottom: 15 }]}>
            <LinearGradient
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              colors={['#614698', '#614698', '#614698']} style={[Helpers.bigBtnGradient]} >
              <TouchableOpacity style={Helpers.btn}
                //zonPress={this._onLoginPressButton.bind(this)}
              >
                <Text style={[Helpers.btnText, { color: Colors.white, fontSize: 15  }]}>Continue</Text>

              </TouchableOpacity>

            </LinearGradient>
          </View>

      </SafeAreaView>
    );
  }
}

UserLicense.propTypes = {
  authenticatedUser: PropTypes.object,
  authenticatedIsLoading: PropTypes.bool,
  authenticatedErrorMessage: PropTypes.string,
  accountType: PropTypes.any,
  authenticateUser: PropTypes.func,
  resetAuthenticateStates: PropTypes.func,
  selectedMessage: PropTypes.any
}

const mapStateToProps = (state) => ({
  authenticatedUser: state.authenticate.authenticatedUser,
  authenticatedIsLoading: state.authenticate.authenticatedIsLoading,
  authenticatedErrorMessage: state.authenticate.authenticatedErrorMessage,
  accountType: state.authenticate.accountType,
  selectedMessage: state.startup.selectedMessage

})

const mapDispatchToProps = (dispatch) => ({
  authenticateUser: (data) => dispatch(AuthenticateActions.authenticateUser(data)),
  resetAuthenticateStates: () => dispatch(AuthenticateActions.resetAuthenticateStates()),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UserLicense)

const styles = StyleSheet.create({});


